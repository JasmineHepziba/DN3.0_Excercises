package com.librarymanagement.librarymanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryManagementAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
