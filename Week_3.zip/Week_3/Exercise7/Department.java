package com.example.employeemanagementsystem.entity;

import javax.persistence.Entity;

@Entity
public class Department extends AuditableEntity {

    // Existing fields and methods
}