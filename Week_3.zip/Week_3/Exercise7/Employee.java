package com.example.employeemanagementsystem.entity;

import javax.persistence.Entity;

@Entity
public class Employee extends AuditableEntity {

    // Existing fields and methods
}