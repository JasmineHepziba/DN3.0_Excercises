public class Main {
    public static void main(String[] args) {
        Order[] orders = new Order[] {
            new Order(1, "Customer 1", 100.0),
            new Order(2, "Customer 2", 50.0),
            new Order(3, "Customer 3", 200.0),
            new Order(4, "Customer 4", 150.0),
            new Order(5, "Customer 5", 80.0)
        };

        System.out.println("Before sorting:");
        printOrders(orders);

        // Bubble Sort
        BubbleSort.sort(orders);
        System.out.println("After Bubble Sort:");
        printOrders(orders);

        // Quick Sort
        orders = new Order[] {
            new Order(1, "Customer 1", 100.0),
            new Order(2, "Customer 2", 50.0),
            new Order(3, "Customer 3", 200.0),
            new Order(4, "Customer 4", 150.0),
            new Order(5, "Customer 5", 80.0)
        };
        QuickSort.sort(orders);
        System.out.println("After Quick Sort:");
        printOrders(orders);
    }

    public static void printOrders(Order[] orders) {
        for (Order order : orders) {
            System.out.println("Order ID: " + order.orderId + ", Customer Name: " + order.customerName + ", Total Price: " + order.totalPrice);
        }
        System.out.println();
    }
}