public class ExcelDocumentImpl extends ExcelDocument {
    public ExcelDocumentImpl() {
        System.out.println("Creating Excel document...");
    }
}